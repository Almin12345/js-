const pokreniAnimaciju = () => {
    let text = document.querySelector('h1')
    text.className = 'animated'
}


let line = document.querySelector('.line')
let lineWidth = 50;

const smanji = () => {
    lineWidth -= 5

    if(lineWidth < 0){
        lineWidth = 0
    }
    line.style.width = lineWidth + '%'
}

const povecaj = () => {
    lineWidth += 5
    if(lineWidth > 100){
        lineWidth = 100
    }

    line.style.width = lineWidth + '%'
}


const showImages = () => {
    let leftImg = document.querySelector('.left')
    let rightImg = document.querySelector('.right')
    rightImg.classList.add('animated')
    leftImg.classList.add('animated')

    console.log(rightImg)
}