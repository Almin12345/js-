/*
let logo = document.querySelector('.lnXdpd')
logo.src = chrome.runtime.getURL('img/cysecor_logo.png')
logo.srcset = chrome.runtime.getURL('img/cysecor_logo.png')
*/
let googleLogo = document.querySelector('.logo img');
googleLogo.src = chrome.runtime.getURL('img/cysecor_logo.png')
googleLogo.style.width = '50px'
googleLogo.style.height = '50px'