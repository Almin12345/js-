
/* ovo su objekti*/
let data = {
    Ime : "Niko",
    Prezime  : "Nikolic",
    godine     : 24,
    visina  : 184
  };
  
document.querySelector("#podaci").innerHTML
= 'Korisnik: ' + data.Ime + ' ' + data.Prezime + ' ima ' 
+ data.godine + ' godine i  visok je ' + data.visina + 'cm';

/* ovo je if petlja*/
let prvi_broj = 7;
let drugi_broj = 10;
let petlje = document.querySelector('#petlje')
if(prvi_broj > drugi_broj){
    petlje.innerText = 'prvi broj je veci'
}else{
    petlje.innerText = 'drugi broj je veci'
}

/* ovo je while petlja*/
let whilePetlja = document.querySelector('#while')
while(drugi_broj > prvi_broj){
    prvi_broj++;
    if(prvi_broj === drugi_broj){
        whilePetlja.innerText = 'prvi i drugi broj su sada jednaki'
    }
}

/* ovo je for petlja */
let forPetlja =  document.querySelector('#for')
for(let visina in data){
    forPetlja.innerText = `${visina}: ${data[visina]}`
}

/* ovo je click event*/

let clickEvnet = document.querySelector('#clickEvent')
clickEvnet.addEventListener("click", () => {
    clickEvnet.style.backgroundColor = 'yellow'
})

/* ovo je mouseenter i mouse leave event*/
let promeniBojuTexta = document.querySelector('.domaci')
promeniBojuTexta.addEventListener("mouseenter", () => {
    promeniBojuTexta.style.color = 'red'
})

promeniBojuTexta.addEventListener("mouseleave", () => {
    promeniBojuTexta.style.color = 'black'
})

/* ovo je keyup i keydown event*/
let keyUp = document.querySelector('#keyup')
window.addEventListener("keyup", () => {
    keyUp.innerText = 'keyup'
})

window.addEventListener("keydown", () => {
    keyUp.innerText = 'keydown'
})

/* ovo je switch */

let day;
switch (new Date().getDay()) {
  case 0:
    day = "Nedelja";
    break;
  case 1:
    day = "Ponedeljak";
    break;
  case 2:
    day = "Utorak";
    break;
  case 3:
    day = "Sreda";
    break;
  case 4:
    day = "Cetvrtak";
    break;
  case 5:
    day = "Petak";
    break;
  case  6:
    day = "Subota";
}
document.getElementById("dan").innerHTML = "Danas je " + day;