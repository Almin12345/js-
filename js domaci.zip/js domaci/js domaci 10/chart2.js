let xValues = [1, 5, 10, 15, 20, 25, 30, 1, 5, 10, 15];
let yValues = [45, 46, 47, 47.5, 48, 48.5, 49, 50, 51, 51.2];

new Chart("Chart", {
  type: "line",
  data: {
    labels: xValues,
    datasets: [{
      fill: false,
      lineTension: 0,
      backgroundColor: "rgba(0,255,0,1.0)",
      borderColor: "rgba(0,255,0,1)",
      data: yValues
    }]
  },
  options: {
    legend: {display: false},
    scales: {
      yAxes: [{ticks: {min: 6, max:16}}],
    }
  }
});

