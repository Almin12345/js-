let allTotal = 0;
const buyFilm = (element) => { 
        let price = element.previousElementSibling.innerText
        price2 = price.slice(5, 10)
        price3 = parseFloat(price2)
        allTotal += price3

        let potroseniNovac = document.querySelector('#potroseniNovac')
        potroseniNovac.innerText = 'Potroseni novac: ' + allTotal.toFixed(2)

        element.innerText = 'Hvala na gledanju'
        element.setAttribute('disabled', 'true')
        element.style.color = 'black'
        element.style.background = 'gray'

}

