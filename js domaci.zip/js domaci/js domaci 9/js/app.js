let session = new Session()
session = session.getSession()

if(session !== ''){
    window.location.href = "hexa.html"
}

document.querySelector('#openRegister').addEventListener('click', () => {
    let register = document.querySelector('.register')
    register.style.display = 'block'
});

document.querySelector('#closeModal').addEventListener("click", () => {
    let register = document.querySelector('.register')
    register.style.display = 'none'
});

document.querySelector('#ovde').addEventListener("click", () => {
    let register = document.querySelector('.register')
    register.style.display = 'none'
});


let config = {
    'korisnicko_ime': {
        required: true,
        minlength: 5,
        maxlength: 50,
    },
    'email': {
        required: true,
        email: true,
        minlength: 5,
        maxlength: 50,
    },
    'lozinka': {
        required: true,
        minlength: 7,
        maxlength: 25,
        matching: 'ponovi_lozinku'
    },
    'ponovi_lozinku': {
        required: true,
        minlength: 7,
        maxlength: 25,
        matching: 'lozinka'
    }
};

let validator = new Validator(config, '#registerForm');

document.querySelector('#registerForm').addEventListener("submit", e => {
    e.preventDefault()

    if(validator.validationPassed()){
        
        let user = new User();
        user.username = document.querySelector('#korisnicko_ime').value
        user.email = document.querySelector('#email').value
        user.password = document.querySelector('#lozinka').value
        user.create();

    }
})


document.querySelector('#loginForm').addEventListener("submit", e => {
    e.preventDefault()

    let email = document.querySelector('#login_email').value;
    let password = document.querySelector('#login_password').value

    let user = new User();
    user.email = email;
    user.password = password;
    user.login()
})

