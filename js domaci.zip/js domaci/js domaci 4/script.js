    let btn = document.querySelector('button')
    let list = document.querySelector('nav ul')

    btn.addEventListener("click", () => {
        if(btn.innerText === 'menu'){
            list.style.display = 'block'
            btn.innerText = 'close'
        }else{
            list.style.display = 'none'
            btn.innerText = 'menu'
        }
    })

let leftBtn = document.querySelector('#leftBtn')
let rightBtn = document.querySelector('#rightBtn')
let img = document.querySelectorAll('.image-wrapper img')
let position = 0;

leftBtn.addEventListener("click", () => {
    displayNone()
    position--;

    if(position === -1){
        position =  img.length -1;
    }


    img[position].style.display = 'block'
})

rightBtn.addEventListener("click", () => {
    displayNone()
    position++;

    if(position === img.length){
        position = 0;
    }

    img[position].style.display = 'block'
})

const displayNone = () => {
    img.forEach( (img) => {
        img.style.display = 'none'
    })
}




let Btns = document.querySelectorAll('.portfolio-categories button')

Btns.forEach( (btn1) => {
    btn1.addEventListener("click", () => {
        let category = btn1.getAttribute('data-category')
        let singleItem = document.querySelectorAll('.portfolio-single-item')

        singleItem.forEach( (item) => {
            item.style.display = 'none'
        })

        if(category === "sve"){
            singleItem.forEach( (item) => {
                item.style.display = 'block'
            })
        }

        singleItem.forEach( (item) => {
            if(item.getAttribute('data-category').includes(category)){
                item.style.display = 'block'
            }
        })

    })
})


let otvoriModal = document.querySelector('#openModal')
let modal = document.querySelector('.modal')
let overlay = document.querySelector('.overlay')

otvoriModal.addEventListener("click", () => {
    modal.style.display = 'block'
    overlay.style.display = 'block'
})

let zatvoriModal = document.querySelector('#zatvoriModal')

zatvoriModal.addEventListener("click", () => {
    modal.style.display = 'none'
    overlay.style.display = 'none'
})