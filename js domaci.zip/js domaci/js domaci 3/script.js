let promeniBoju = document.querySelector('#promeniBoju')

promeniBoju.addEventListener("click", (event) => {
    if(promeniBoju.innerText === 'promeni boju'){
        promeniBoju.style.color = 'red'
        promeniBoju.innerText = 'crvena'
    }else if(promeniBoju.innerText === 'crvena'){
        promeniBoju.style.color = 'blue'
        promeniBoju.innerText = 'plava'
    }else if(promeniBoju.innerText === 'plava'){
        promeniBoju.style.color = 'black'
        promeniBoju.innerText = 'crna'
    }else if(promeniBoju.innerText === 'crna'){
        promeniBoju.innerText = 'promeni boju'
    }
});

let box = document.querySelector('.box');
let header = document.getElementById('box1')

box.addEventListener("mousemove", () => {
    box.style.width = '200px'
    box.style.height = '200px'
    header.style.display = 'block'
})


box.addEventListener("mouseleave", () => {
    box.style.width = '100px'
    box.style.height = '100px'
    header.style.display = 'none'
})


let forma =  document.querySelector('form')
let btn = document.querySelector('button')

forma.addEventListener("submit", () => {
    alert('uspesno ste porvrdili formu')
})

let bodi = document.querySelector('.body1')

window.addEventListener("resize", () => {
    if(window.innerWidth > 1000){
        bodi.style.background = 'red'
    }else{
        bodi.style.background = 'green'
    }
})


