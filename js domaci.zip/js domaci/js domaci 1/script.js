const inputFunction = (element) => {
    let input = document.querySelector('input').value
    let outputs = document.querySelector('.outputs')
    let list = document.querySelector('.list')
    let lista = document.querySelector('ul')
    let btn = document.querySelector('#myButton')

         if(input === ""){
            alert('morate upisati nesto')

            outputs.innerHTML +=``
         }else{
            outputs.innerHTML += `<div class="outputs">
            <div class="list">
                <ul>
                    <li>${input}</li>
               </ul>   

               <button onclick="removeButton(this)" class="removeButton">X</button>
               
            </div>
        </div>`

        let input2 = document.querySelector('input').value = ''
      }
}   

const removeButton = (element) => {
    let outputs = document.querySelector('.outputs')
    let list = document.querySelector('.list')
    
    list.remove()
}
